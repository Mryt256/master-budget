document.addEventListener("DOMContentLoaded", () => {
    const ctx = document.getElementById('budgetChart').getContext('2d');
    const budgetList = document.getElementById('budgetList');
    const budgetForm = document.getElementById('budgetForm');

    // Initialize data for the pie chart
    const data = {
        labels: ['Tuition', 'Food', 'Accommodation', 'Transport', 'Luxury'],
        datasets: [{
            data: [0, 0, 0, 0, 0],
            backgroundColor: ['#ff6384', '#36a2eb', '#ffcd56', '#4bc0c0', '#9966ff'],
            hoverOffset: 4
        }]
    };

    // Create the pie chart
    const budgetChart = new Chart(ctx, {
        type: 'pie',
        data: data
    });

    // Function to update chart data
    const updateChart = () => {
        budgetChart.update();
    };

    // Add budget item and update chart
    document.getElementById('addBudget').addEventListener('click', () => {
        const tuition = parseFloat(document.getElementById('tuition').value) || 0;
        const food = parseFloat(document.getElementById('food').value) || 0;
        const accommodation = parseFloat(document.getElementById('accommodation').value) || 0;
        const transport = parseFloat(document.getElementById('transport').value) || 0;
        const luxury = parseFloat(document.getElementById('luxury').value) || 0;

        // Update chart data
        data.datasets[0].data = [tuition, food, accommodation, transport, luxury];
        updateChart();

        // Add items to the list
        const listItem = document.createElement('li');
        listItem.innerHTML = `
            Tuition: ${tuition}, Food: ${food}, Accommodation: ${accommodation}, Transport: ${transport}, Luxury: ${luxury}
            <button class="delete-btn">Delete</button>
        `;

        budgetList.appendChild(listItem);

        // Delete button functionality
        listItem.querySelector('.delete-btn').addEventListener('click', () => {
            listItem.remove();
            data.datasets[0].data = [0, 0, 0, 0, 0];
            updateChart();
        });

        // Clear input fields
        budgetForm.reset();
    });
});